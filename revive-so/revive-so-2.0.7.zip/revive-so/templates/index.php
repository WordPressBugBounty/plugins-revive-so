<?php
//silence is Golden

